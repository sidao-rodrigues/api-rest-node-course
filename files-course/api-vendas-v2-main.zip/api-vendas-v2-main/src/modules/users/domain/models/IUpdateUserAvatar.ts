export interface IUpdateUserAvatar {
  user_id: string;
  avatarFilename: string;
}
