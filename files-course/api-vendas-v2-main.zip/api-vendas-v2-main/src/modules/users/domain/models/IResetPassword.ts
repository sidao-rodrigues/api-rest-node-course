export interface IResetPassword {
  token: string;
  password: string;
}
