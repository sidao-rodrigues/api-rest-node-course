export interface IShowUser {
  id: string;
}
