export interface ISendForgotPasswordEmail {
  email: string;
}
