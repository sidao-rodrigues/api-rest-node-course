export interface ICreateSession {
  email: string;
  password: string;
}
