export interface IUpdateStockProduct {
  id: string;
  quantity: number;
}
