export interface IShowProduct {
  id: string;
}
