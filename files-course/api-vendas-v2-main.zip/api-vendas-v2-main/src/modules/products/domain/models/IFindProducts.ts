export interface IFindProducts {
  id: string;
}
