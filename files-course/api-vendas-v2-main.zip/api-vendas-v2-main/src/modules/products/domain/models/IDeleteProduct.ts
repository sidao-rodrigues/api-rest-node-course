export interface IDeleteProduct {
  id: string;
}
