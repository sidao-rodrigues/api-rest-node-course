export interface ICreateProduct {
  name: string;
  price: number;
  quantity: number;
}
