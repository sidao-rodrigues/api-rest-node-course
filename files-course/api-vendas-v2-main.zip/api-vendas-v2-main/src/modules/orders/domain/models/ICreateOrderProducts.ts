export interface ICreateOrderProducts {
  product_id: string;
  price: number;
  quantity: number;
}
