export interface IDeleteCustomer {
  id: string;
}
