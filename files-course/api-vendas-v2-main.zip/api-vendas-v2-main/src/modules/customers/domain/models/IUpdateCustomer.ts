export interface IUpdateCustomer {
  id: string;
  name: string;
  email: string;
}
