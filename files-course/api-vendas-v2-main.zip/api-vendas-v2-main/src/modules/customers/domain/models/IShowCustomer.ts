export interface IShowCustomer {
  id: string;
}
