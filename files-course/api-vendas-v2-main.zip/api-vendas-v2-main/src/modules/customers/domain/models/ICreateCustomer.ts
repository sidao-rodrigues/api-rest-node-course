export interface ICreateCustomer {
  name: string;
  email: string;
}
