export interface ICustomer {
  id: string;
  name: string;
  email: string;
  created_at: Date;
  updated_at: Date;
}
